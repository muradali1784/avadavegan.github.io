var con = document.querySelector(".container");
var iconLove = document.querySelector("i");


con.addEventListener("dblclick", function(){
    
        iconLove.style.transform = "translate(-50%,-50%) scale(1)";
        iconLove.style.opacity = 0.8
        iconLove.style.color = "red"

        setTimeout(function(){
            iconLove.style.opacity= 0
        },1000)

        setTimeout(function(){
            iconLove.style.transform = "translate(-50%,-50%) scale(0)";

        },2000)

  
   
    
})