/* changing html elements by javascript */


// var headingOne = document.querySelector("h2").innerHTML="I can do everything in JavaScript";
// console.log(headingOne);

/* changing css properties ny javascript */

// var headingOne = document.querySelector("h2");
// headingOne.style.color = "red"
// headingOne.style.backgroundColor = "purple"
// console.log(headingOne);

/* event listener in javascript */

// var headingOne = document.querySelector("h2");

// headingOne.addEventListener("click", function(){
//     headingOne.innerHTML="Working on DOM manipulation topic";
//     headingOne.style.color = "blue";
//     headingOne.style.backgroundColor = "yellow";
//     headingOne.style.cursor = "pointer";
//     console.log(headingOne);
// })

/* example of bulb on and off */

// var bulb = document.querySelector("#bulb")
// var btn = document.querySelector("button")

// var flag = 0;

// btn.addEventListener("click",function(){

//     if(flag == 0){
//     bulb.style.backgroundColor = "yellow"
//     flag = 1;
//     }
//     else
//     {
//         bulb.style.backgroundColor = "white"
//         flag = 0;
//     }
    
// })


// var h = document.querySelectorAll("h1")

// h.forEach((ele) =>{
//     console.log(ele);
// })


// var s = document.querySelector("#myDIV")
// s.addEventListener("mousemove", myFunction)
// function myFunction(){
//     document.querySelector("#demo").innerHTML = Math.random();
// }

// function removeHandler() {
//     document.querySelector("#myDIV").removeEventListener("mousemove", myFunction

//  );
// }
// function addHandler() {
//     document.querySelector("#myDIV").addEventListener("mousemove", myFunction

//  );
// }





