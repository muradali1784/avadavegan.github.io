

// adding text to paragragh by variables

// let addText = "Murad Ali";
// document.getElementById("demo").innerHTML= addText;

//show power of x variable
// let y = 5;
// document.getElementById("demo").innerHTML = Math.pow(y,3);

//showing exponential of variables
// let z = 10;
// z **=5;
// document.getElementById("demo1").innerHTML= "the value of x:" + z;

// creating objects in javascript
// const person = {firstName:"Murad", lastName: "ali", lastEdu:"Beachalar of Science"};
// console.log(person);

// //creating array in javascript
// const person1=["BMW", "Honda", "ferrari"]
// console.log(person1);

// let x = 2 + "murad ali";
// document.getElementById("demo1").innerHTML="the value of x: " + x;

// function solve(){
//     var age = 25;
// }
// solve();
// console.log(age);    //it through error while giving output. age is only accessible in function scope only


// function solve(){
//     let age = 25;
//     console.log(age);
// }
// solve();

// what is ternay operator?

// let myAge = 25;
// (myAge >= 18) ? (console.log("Can drive car")) : (console.log("Cannot Drive car"));

// let studGrade = 90;
// let statusGrade = (studGrade=> 80) ? (console.log("grade A")):(console.log("You are have less grade"));
// console.log(statusGrade);

// template litral concept

// let num1 = 12;
// let num2 = 122;

// let sum = num1 + num2;

// console.log(` The sum of ${num1} + ${num2} is equel to ${sum}`);

//printing multi-line string
// let string1 = "Murad Ai From Pakistan";

// let string2 = "Rehman From UAE";

// let multiLineString = `
//     ${string1},
//     ${string2}`

// console.log(multiLineString);


/*
Conditional If else statements
*/

// let age = 54;
// if(age >=18){
//     console.log("Can vote...")

// }
// else{
//     console.log("Cannot vote...")

// }

/* if else if satement */

// let number = parseInt(prompt("Enter a number"));

// if(number == 1)
// {
//     let grade = alert("Grade A")
//     console.log(grade);
// }
// else if(number == 2)
// {
//     let grade = alert("Grade B")
//     console.log(grade);

// }
// else if(number == 3)
// {
//     let grade = alert("Grade C")
//     console.log(grade);

// }
// else if(number == 4)
// {
//     let grade = alert("Grade D")
//     console.log(grade);

// }
// else if(number == 5)
// {
//     let grade = alert("Grade E")
//     console.log(grade);

// }


// else
// {
//     let grade = alert("Your grade id F, try next for exam...")
//     console.log(grade);
// }

/* switch satements */

// let day = 5;
// switch(day){
//     case 1: 
//            console.log("Sunday"); break;
//     case 2: 
//            console.log("Monday"); break;
//     case 3: 
//            console.log("Tuesday"); break;
//     case 4: 
//            console.log("Wednesday"); break;
//     case 5: 
//            console.log("Thursday"); break;
//     case 6: 
//            console.log("Friday"); break;
//     case 7: 
//            console.log("Satureday"); break;
//     default: 
//            console.log("Inter Invalid day");
// }


/* Array concept */

// let stuMarks = [12,32,90,48,89,90,67];
// console.log(stuMarks); 
// console.log(stuMarks.length); //checking the full length of arr
// console.log(stuMarks[0]);
// console.log(stuMarks[1]);
// console.log(stuMarks[2]);
// console.log(stuMarks[2]= 10000);  // change the arr element

// let heros =["Murad", "Ali", "Rehman", "Imran Khan", "Pak Phooj", "Pak Army", "Pakistan Navy"];
//iterate on arr through for loop
// for(i = 0; i<heros.length; i++){
//     console.log(heros[i]);
// }
//iterate on arr through for of

// for( let hero of heros){
//     console.log(hero);
// }

/* calculate the average of array */

// let marks =[89,29,90,63,90,78,87,79];
// let sum = 0;
// for(let val of marks){
//     sum = sum + val;
// }
// let avg = sum / marks.length;

// console.log(`the average of array is  = ${avg}`);

// let arr = [560,281,902,190,239];

// for(i = 0; i <arr.length; i++){
//     let offer = arr[i]/10;
//     arr[i]-= offer;
// }
// console.log(arr);

/* array methods */

// let arrLength = [1,2,3,4,6,7,8,9,10,872];
// // arrLength.pop();
// // arrLength.push("Murad");
// // arrLength.toString();
// console.log(arrLength);

// let laptopList = ["Apple", "HP", "Dell", "Tosheeba", "Thinkpad"];
// let mobileList = ["Iphone","Samsung", "Andriod"];
// let webTech = ["front-end develop", "Backend developer"];

// let joinList = laptopList.concat(mobileList, webTech);
// console.log(joinList);


// mobileList.unshift("q mobile phone"); 
// console.log(mobileList)

// mobileList.shift();
// console.log("deleted item", mobileList);


// let data = [1,2,3,4,5,90,6,7,8]
// console.log(data.slice(1,3));
// console.log(data.slice(1));
// console.log(data.slice(-8));

// let data = [1,2,3,4,5,90,6,7,8]
// // console.log(data.splice(1,2));
// // data.splice(1,2,222,333,378,282); //deleting two element fromm array and adding new element on it
// // console.log(data);

// data.splice(8,0,222,333,378,282); //adding element in a array at specific index
// console.log(data);


// let data = [1,2,3,4,5,90,6,7,8]
// data.indexOf("one is found at index of", 1) + 1;
// console.log(data);

// let fruits = ["banana","apple","Mangos","pineapple"]

// fruits.forEach(function(fruitName){
//     console.log(fruitName);
// })

// fruits.forEach((fruitsName)=>{            //arrow funtion or annonimys and recommended in js programming
// console.log(fruitsName);
// })

// function abc(el){
//     console.log(el);
// }
// fruits.forEach(abc)

/* concept of foreach map,filter and reduce */

let month = ["Jan", "Feb","April","May","June","July","Auguest","December"];

//map return a new array with elements but it does not change original list

// const capitalizeMotnh = month.forEach((month, i) => {    
//         console.log(month, i+1);
//         return month.toUpperCase();
    
//     })

// const capitalizeMotnh = month.map((month, i) => {    
//         console.log(month, i+1);
//         return month.toUpperCase();
    
//     })


// const filteredMotnh = month.filter((month, i) => {    //you filter the month arry by value 
//         // console.log(month, i+1);
//         return month.toLowerCase().includes("m")
    
//     })

// const filteredMotnh = month.filter((month, i) => {     //you filter arr by index 
//         // console.log(month, i+1);
//         return i >=3
    
//     })

/* Filter the student whose equel and above 18


*/
// let students = [
//     {
//         name:"Murad",
//         age: 15,
//     },
//     {
//         name:"Raza",
//         age: 10,
//     },
//     {
//         name:"Akash",
//         age: 18,
//     },
//     {
//         name:"Ejaz",
//         age: 28,
//     },
//     {
//         name:"Ifthakar",
//         age: 20,
//     },
// ]

// const adultStudents = students.filter((students) => {    //here you are getting whole object in a array
//     return students.age >= 18

// }).map((students) =>{                    //here you can get only name of student
//     return students.name
// }).filter((students) =>{
//     return students.includes("A")
// // })

// /* let understand the concept of reduce */

// let nums = [1,2,3,4,5];

// // nums.reduce((accu, curr, i)=>{
// //     // console.log(i, curr)
// //     console.log(i, accu)
// //     return 'murad ali'

// // }, 'sdja')

// let sum = nums.reduce((accu, curr, i)=>{
//     // console.log(i, curr)
//     // console.log(accu, curr)
//     return accu + curr
    

// }, 0)


/* While and do while loop */

// idx = 0;
// while(idx<10){
//     console.log(`the while loop start from 0 and end 9: ${idx}`);
//     idx++;
// }

// let myArr =["murad", "ali", "raza"];
// let idx = 0;
// while(idx<=myArr.length){
//     console.log(`the value is : ${myArr[idx]}`);
//     idx = idx + 1;
// }

// let score = 0;
// do{
//     console.log(`the value of score: ${score}`);
//     score++;

// }while(score<=10);

// const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// numbers.map((items)=>{
// console.log(`valus is doubled: ${items*2}`);
// })

// const even = numbers.filter(items =>{   //to get even numbers
//     return items % 2 ===0
// });

// console.log(even);

// const even = numbers.filter(items =>{   //to get odd numbers
//     return items % 2 ===1
// });

// console.log(even);

// const students = [
//     { name: 'Quincy', grade: 96 },
//     { name: 'Jason', grade: 84 },
//     { name: 'Alexis', grade: 100 },
//     { name: 'Sam', grade: 65 },
//     { name: 'Katie', grade: 90 }
//   ];

// const brilientStudent = students.filter((student)=>{
//     return student.grade >= 90

// }).map((students)=>{
//     return students.name

// })


   



