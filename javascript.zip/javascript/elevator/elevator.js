let mainDiv = document.querySelector(".main");
let divBlack = document.querySelector(".submain");
let upButton = document.querySelector(".upBtn");
let downButton = document.querySelector(".downBtn")
let btn1 = document.querySelector(".btn1");
let btn2 = document.querySelector(".btn2");
let btn3 = document.querySelector(".btn3");


upButton.addEventListener("click", () => {
    divBlack.style.marginBottom = "600px";
    divBlack.style.transition = "ease 0.5s";
    divBlack.style.backgroundColor = "green";
   

})
btn1.addEventListener("click", () => {
    divBlack.style.marginBottom = "200px";
    divBlack.style.backgroundColor = "brown";
    divBlack.style.transition = "ease 0.5s";
    const el = document.createElement("p");
    divBlack.innerHTML = "<p>You are reached at 1st floor...</p>";

 
})
btn2.addEventListener("click", () => {
    divBlack.style.marginBottom = "300px";
    divBlack.style.backgroundColor = "purple";
    divBlack.style.transition = "ease 0.5s";
    const el = document.createElement("p");
    divBlack.innerHTML = "<p>You are reached at 2st floor...</p>";

})
btn3.addEventListener("click", () => {
    divBlack.style.marginBottom = "500px";
    divBlack.style.backgroundColor = "yellow";
    divBlack.style.transition = "ease 0.5s";
    const el = document.createElement("p");
    divBlack.innerHTML = "<p>You are reached at 3st floor...</p>";

})
downButton.addEventListener("click", ()=>{
    divBlack.style.marginBottom = "0";
    divBlack.style.backgroundColor = "black";
    
})

