// const ul = document.querySelector("ul");
// const li = document.querySelector("li");

// const newLi = document.createElement("li");



// console.log(ul.appendChild(newLi));
// newLi.innerText = "Contact";

// //modifying and attributes and classes

// /* 
// newLi.setAttribute("id","text-items");
// newLi.removeAttribute("id");

// const title = document.querySelector("#main-heading");
// console.log(title.getAttribute("id"));
// */

// //modifying classes
// /*
// newLi.classList.add("list-items")
// newLi.classList.remove("list-items")
//  */

// //remove element
// newLi.remove();


//traverse the dom
//parent node traversal
//  const ul = document.querySelector("ul");

//  console.log(ul.parentNode.parentNode);
//  console.log(ul.parentElement.parentElement);

// const html = document.documentElement;
// console.log(html.parentElement);
// console.log(html.parentNode);

//child node traversal
// const ul = document.querySelector("ul");
// console.log(ul.childNodes);
// console.log(ul.firstChild);
// console.log(ul.lastChild);
// ul.childNodes[1].style.backgroundColor = "red";

// console.log(ul.children);
// console.log(ul.firstElementChild);
// console.log(ul.lastElementChild);

//sibling node traversal
// const ul = document.querySelector("ul");
// console.log(ul.previousSibling);
// console.log(ul.nextSibling);



const quote = document.querySelector(".quote");
const person = document.querySelector(".person");
const btn = document.querySelector(".new-quote");

const quotes = [{
    quote:`"Fortune favors the bold"`,
    person:`Virgil`
},
{
    quote:`"I think, therefore I am."`,
    person:`René Descartes`
},
{
    quote:`"Time is money."`,
    person:`Benjamin Franklin`
},
{
    quote:`"I came, I saw, I conquered."`,
    person:`Julius Caesar`
},
{
    quote:`"When life gives you lemons, make lemonade."`,
    person:`Elbert Hubbard`
},
{
    quote:`"I love you the more in that I believe you had liked me for my own sake and for nothing else."`,
    person:`John Keats`
},
{
    quote:`"But man is not made for defeat. A man can be destroyed but not defeated."`,
    person:`Ernest Hemingway`
},];

btn.addEventListener("click", function(){
    let random = Math.floor(Math.random()* quotes.length);
    quote.innerHTML = quotes[random].quote;
    person.innerHTML = quotes[random].person;
})



const openBtn = document.querySelector("#open-btn");
const modelContainer = document.querySelector("#model-container")
const closeBtn = document.querySelector("#close-btn");

openBtn.addEventListener("click", function(){
    modelContainer.style.display = "block";

});
closeBtn.addEventListener("click", function(){
    modelContainer.style.display = "none";
});

window.addEventListener("click", function(e){
    if(e.target === modelContainer){
        modelContainer.style.display = "none";
    }
   

});

const accordion = document.getElementsByClassName("content-container");

for(i = 0; i < accordion.length; i++) {

    accordion[i].addEventListener("click", function(){
        this.classList.toggle('active');
    })

}