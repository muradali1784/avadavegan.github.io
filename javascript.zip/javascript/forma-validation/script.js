var u_name = document.myForm.u_name;
var u_pass = document.myForm.u_pass;

function validate(field){
    if(field === "name_field"){
        if(u_name.value){
            u_name.classList.remove("is-invalid");
            u_name.classList.add("is-valid");
            document.getElementById("name-validation").innerHTML= "";
           }else{
            u_name.classList.remove("is-valid");
            u_name.classList.add("is-invalid");
            document.getElementById("name-validation").innerHTML= "Name field is required*...";
        
           }
    }
    else if(field === "password_field"){
        if(u_pass.value){
            u_pass.classList.remove("is-invalid");
            u_pass.classList.add("is-valid");
            document.getElementById("password-validation").innerHTML = ""
           }else{
            u_pass.classList.remove("is-valid");
            u_pass.classList.add("is-invalid");
            document.getElementById("password-validation").innerHTML = "Password field is required*...."
        
           }
    }





}