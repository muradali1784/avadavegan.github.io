const stuData = {
    firstName: "Murad",
    lastName:"ali",
    age:25,
    email:"muradali182@gmail.com",
    addDay:["Monday", "Tuesday","Satureday"],
    isLoggned:false

}
console.log(stuData.firstName);
console.log(stuData.email);
